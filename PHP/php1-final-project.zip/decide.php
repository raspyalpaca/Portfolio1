<?php
require_once("config.php");
require_once("Nav-bar.php");

?>

<div class="decide">
    <a href="pets.php">
        <img src="images/Adoptpet.jpg" width="400" height="400" >
    </a>

    <a href="myaccount.php">
        <img src="images/Giveforadoption.jpeg" width="400" height="400">
    </a>
</div>